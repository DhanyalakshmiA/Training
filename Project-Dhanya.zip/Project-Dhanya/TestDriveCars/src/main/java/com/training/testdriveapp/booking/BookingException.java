package com.training.testdriveapp.booking;

public class BookingException {
}
