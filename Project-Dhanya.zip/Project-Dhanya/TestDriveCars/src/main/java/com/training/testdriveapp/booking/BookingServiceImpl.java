package com.training.testdriveapp.booking;

public class BookingServiceImpl {
}
