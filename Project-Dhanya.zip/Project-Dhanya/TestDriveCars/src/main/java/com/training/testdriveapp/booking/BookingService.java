package com.training.testdriveapp.booking;

public interface BookingService {
}
