package com.training.testdriveapp.admin;

public class AdminException {
}
