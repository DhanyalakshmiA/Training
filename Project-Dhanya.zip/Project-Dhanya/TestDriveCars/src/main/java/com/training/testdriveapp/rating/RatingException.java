package com.training.testdriveapp.rating;

public class RatingException {
}
