package com.training.testdriveapp.rating;

public interface RatingService {
}
