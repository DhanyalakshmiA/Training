package com.training.testdriveapp.customer;

public class CustomerException extends Exception {
    public CustomerException(String message)
    {
        super(message);
    }
}
