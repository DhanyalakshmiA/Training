package com.training.testdriveapp.rating;

public class RatingServiceImpl {
}
