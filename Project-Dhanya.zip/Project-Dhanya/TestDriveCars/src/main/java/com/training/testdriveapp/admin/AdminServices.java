package com.training.testdriveapp.admin;

import com.training.testdriveapp.admin.Car;

public interface AdminServices {
    Car addNewCars(Car newCars);
}
