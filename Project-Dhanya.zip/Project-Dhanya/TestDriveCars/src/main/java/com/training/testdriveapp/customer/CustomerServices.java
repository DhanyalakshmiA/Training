package com.training.testdriveapp.customer;

import com.training.testdriveapp.customer.Customer;

public interface CustomerServices {
    Customer addNewCustomer(Customer newCustomer);
}
