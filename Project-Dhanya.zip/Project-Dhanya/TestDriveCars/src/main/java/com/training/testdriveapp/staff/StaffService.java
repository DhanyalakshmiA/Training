package com.training.testdriveapp.staff;

public interface StaffService {
}
