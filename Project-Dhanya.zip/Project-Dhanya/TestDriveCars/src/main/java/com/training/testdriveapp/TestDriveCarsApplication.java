package com.training.testdriveapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestDriveCarsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestDriveCarsApplication.class, args);
	}

}
