package com.training.testdriveapp.rating;

public interface RatingRepository {
}
