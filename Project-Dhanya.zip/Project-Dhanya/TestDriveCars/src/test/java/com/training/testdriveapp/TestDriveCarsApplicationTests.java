package com.training.testdriveapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestDriveCarsApplicationTests {

	@Test
	void contextLoads() {
	}

}
